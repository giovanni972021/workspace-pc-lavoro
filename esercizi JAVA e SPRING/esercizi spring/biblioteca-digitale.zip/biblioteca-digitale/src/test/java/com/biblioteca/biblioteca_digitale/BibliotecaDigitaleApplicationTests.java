package com.biblioteca.biblioteca_digitale;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaDigitaleApplicationTests {

	@Test
	void contextLoads() {
	}

}
