package com.biblioteca.biblioteca_digitale;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibliotecaDigitaleApplication {

	public static void main(String[] args) {
		SpringApplication.run(BibliotecaDigitaleApplication.class, args);
	}

}
