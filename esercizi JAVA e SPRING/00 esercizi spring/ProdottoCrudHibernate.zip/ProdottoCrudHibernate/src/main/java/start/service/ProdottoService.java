package start.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import start.dao.ProdottoDAO;
import start.model.Prodotto;
import start.repository.ProdottoRepository;

@Service
public class ProdottoService implements ProdottoDAO{

	@Autowired
	//Questo oggetto viene configurato automaticamente da Spring
	//Inizializzato dall'applicazione che cerca un oggetto repository uguale a questo
	ProdottoRepository repository;
	
	@Override
	public void inserisciProdotto(Prodotto p) {
		repository.save(p);
		
	}

	@Override
	public Prodotto selezionaProdotto(Integer id) {
		Prodotto p = repository.findById(id).get();
		return p;
	}

	@Override
	public void cancellaProdotto(Prodotto p) {
		// TODO Auto-generated method stub
		repository.delete(p);
	}

	@Override
	public void cancellaProdottoId(Integer id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}

	@Override
	public List<Prodotto> selezionaProdotti() {
		List<Prodotto> lista = (List<Prodotto>)repository.findAll();
		return lista;
	}

	@Override
	public int numeroProdotti() {
		return (int)repository.count();
	}

	@Override
	public void aggiornaProdotto(Prodotto p, Integer id) {
		Prodotto prodottoRecuperato = this.selezionaProdotto(id);
		if(prodottoRecuperato != null) {
			prodottoRecuperato.setNome(p.getNome());
			prodottoRecuperato.setPrezzo(p.getPrezzo());
			repository.save(prodottoRecuperato);
		}else {
			System.out.println("Prodotto non esistente");
		}
		
	}

	@Override
	public List<Prodotto> ordinaPerPrezzo() {
		List<Prodotto> prodotti = repository.findAllByOrderByPrezzoAsc();
		return prodotti;
	}

	@Override
	public Prodotto selezionaProdottoPerNome(String nome) {
		Prodotto selezionato = repository.findProdottoByNome(nome);
		return null;
	}
	
}
