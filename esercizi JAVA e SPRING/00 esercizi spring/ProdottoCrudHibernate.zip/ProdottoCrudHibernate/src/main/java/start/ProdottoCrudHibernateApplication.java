package start;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProdottoCrudHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProdottoCrudHibernateApplication.class, args);
	}

}
