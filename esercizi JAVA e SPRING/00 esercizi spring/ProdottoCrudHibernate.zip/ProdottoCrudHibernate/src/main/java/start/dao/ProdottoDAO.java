package start.dao;

import java.util.List;

import start.model.Prodotto;

public interface ProdottoDAO {
	void inserisciProdotto(Prodotto p);
	Prodotto selezionaProdotto(Integer id);
	Prodotto selezionaProdottoPerNome(String nome);
	void cancellaProdotto(Prodotto p);
	void cancellaProdottoId(Integer id);
	List<Prodotto> selezionaProdotti();
	int numeroProdotti();
	void aggiornaProdotto(Prodotto p, Integer id);
	List<Prodotto> ordinaPerPrezzo();
	
}
