package start.model;

import java.util.Objects;

import jakarta.persistence.*;

@Entity
@Table (name = "prodotto")
public class Prodotto {
	@Column (name = "id")
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private int id;
	@Column (name = "nome", nullable = false)
	private String nome;
	@Column (name = "prezzo")
	private int prezzo;
	
	//lato N della relazione
	/*@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "idUtente")
	private Utente cliente;*/
	
	
	
	public Prodotto(int id, String nome, int prezzo) {
		this.id = id;
		this.nome = nome;
		this.prezzo = prezzo;
	}
	
	public Prodotto(String nome, int prezzo) {
		this.nome = nome;
		this.prezzo = prezzo;
	}
	
	public Prodotto() {
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(int prezzo) {
		this.prezzo = prezzo;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, nome, prezzo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Prodotto other = (Prodotto) obj;
		return id == other.id && Objects.equals(nome, other.nome) && prezzo == other.prezzo;
	}

	@Override
	public String toString() {
		return "Prodotto [id=" + id + ", nome=" + nome + ", prezzo=" + prezzo + "]";
	}
	
	
	
}
