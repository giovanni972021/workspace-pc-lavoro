package start.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.*;

import jakarta.servlet.http.HttpServletRequest;
import start.dao.ProdottoDAO;
import start.model.Prodotto;

@Controller
@RequestMapping("/")
public class ProdottoController {
	@Autowired
	ProdottoDAO service;
	
	@GetMapping("/inserisci")
	public String inserisci(HttpServletRequest request) {
		String nome = request.getParameter("nome");
		Integer prezzo = Integer.parseInt(request.getParameter("prezzo"));
		Prodotto p = new Prodotto(nome,prezzo);
		request.setAttribute("prod", p);
		service.inserisciProdotto(p);
		return "redirect:/home";
	}
	/*
	@GetMapping("/seleziona")
	public String seleziona(HttpServletRequest request) {
		Prodotto p = service.selezionaProdotto(1);
		request.setAttribute("prodotto", p);
		return "seleziona";
	}
	*/
	//In base all'url che arriva (querystring) seleziona il prodotto
	//con l'id che si trova nell'url
	@GetMapping("/seleziona/{id}")
	public String seleziona(@PathVariable("id") Integer idProdotto, HttpServletRequest request) {
		Prodotto p = service.selezionaProdotto(idProdotto);
		request.setAttribute("prodotto", p);
		return "seleziona";
	}
	
	@GetMapping("/cancella/{id}")
	public String cancella(@PathVariable("id") Integer idProdotto, HttpServletRequest request) {
		request.setAttribute("id", idProdotto);
		service.cancellaProdottoId(idProdotto);
		return "redirect:/home";
	}
	
	@GetMapping("/home")
	public String selezionaTutti(HttpServletRequest request) {
		List<Prodotto> lista = service.selezionaProdotti();
		request.setAttribute("listaProdotti", lista);
		return "home";
	}
	
	@GetMapping("/aggiorna/{id}")
	public String aggiorna(@PathVariable("id") Integer idProdotto, HttpServletRequest request) {
		Integer id = Integer.parseInt(request.getParameter("id"));
		String nome = request.getParameter("nome");
		Integer prezzo = Integer.parseInt(request.getParameter("prezzo"));
		Prodotto p = new Prodotto(id,nome,prezzo);
		request.setAttribute("prod", p);
		service.aggiornaProdotto(p, idProdotto);
		return "redirect:/home";
	}
	
	@GetMapping("/formInserisci")
	public String formInserisci(HttpServletRequest request) {
		
		return "prodottoFormInserisci";
	}
	
	@GetMapping("/formUpdate")
	public String formUpdate(HttpServletRequest request) {
		Integer id = Integer.parseInt(request.getParameter("id"));
		String nome = request.getParameter("nome");
		Integer prezzo = Integer.parseInt(request.getParameter("prezzo"));
		Prodotto p = new Prodotto(id,nome,prezzo);
		request.setAttribute("prod", p);
		return "prodottoFormUpdate";
	}
	
	@GetMapping("/ordina")
	public String ordina(HttpServletRequest request) {
		List<Prodotto> prodotti = service.ordinaPerPrezzo();
		request.setAttribute("listaProdotti", prodotti);
		return "homeOrdinata";
	}
	
	
}
